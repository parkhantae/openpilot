"""Low-priority source for explicit Bluetooth physical-indicator mappings."""
import json
from pathlib import Path
import select
import socket
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from openpilot.common.atc_params import right_lane_change_distance
from blink_protocol import PACKAGE_CONFIG, LIMIT, encode, finite, fresh
from blink_policy import Policy, AutomaticSignals
from blink_tbt import TbtBlinker, right_front_clear
from blink_turn_location import observations as turn_observations, navigation_cancelled
from blink_boundary import BoundaryEvents, vehicle_allowed as boundary_vehicle_allowed
from blink_observation import ObservationSignals, LowSpeedOwnership, wire_hold, allowed as observation_allowed
from blink_turn_journey import Travel
from blink_display import Publisher
from blink_feedback import ObservationFeedback
from openpilot.selfdrive.controls.lib.desire_lib.indicator_feedback import TapEcho
from openpilot.selfdrive.controls.lib.desire_lib.boundary_lane import adjacent_lane


def vehicle_ready(sm, now, fingerprint, spas=False):
  """Manual indicators work while driving/engaged; unknown or stale CAN never does."""
  valid = all(sm.valid[k] and sm.alive[k] and
              0 <= now-sm.recv_time[k] < (.75 if k == 'pandaStates' else .35) for k in ('carState', 'carControl', 'selfdriveState', 'pandaStates'))
  c = sm['carState']
  return ((spas or fingerprint == 'HYUNDAI_IONIQ_5_PE') and valid and c.canValid and finite(c.vEgo) and str(c.gearShifter) != 'unknown' and
          len(sm['pandaStates']) > 0)


def automatic_control_allowed(cs, cc, ss, always_lateral, holding_turn):
  # latActive is an actuator-output gate: it drops at a stop and during steering
  # suspension. Neither completes an already-owned physical turn indication.
  # A fresh audio cue may start with lateral permission during a stop or temporary
  # steering suspension; physical turn indication is independent of torque output.
  # Lane-change indications still require actual lateral activation below.
  if str(cs.gearShifter) != 'drive':
    return False
  return cc.latActive or ((ss.active or always_lateral) and cs.latEnabled and
                         not cs.steerFaultTemporary and not cs.steerFaultPermanent)


def turn_heading(sm, now):
  if ('livePose' not in sm.services or not sm.valid['livePose'] or not sm.alive['livePose'] or
      not fresh(sm.recv_time['livePose'], now, .35)):
    return None
  pose = sm['livePose']
  return pose.orientationNED.z if (pose.inputsOK and pose.sensorsOK and pose.posenetOK and
                                  pose.orientationNED.valid and finite(pose.orientationNED.z)) else None


class Events:
  def __init__(self, started):
    self.started = started

  def read(self, journal, settings, status, learning, cancelled, now):
    if not fresh(status.get('time'), now):
      return []
    result = []
    for event in journal.get('events', [])[-64:]:
      if not isinstance(event, dict) or not fresh(event.get('time'), now) or event['time'] < self.started:
        continue
      mac, action = event.get('address'), event.get('action')
      device = settings.get('devices', {}).get(mac, {})
      if (device.get('enabled') is not True or mac not in status.get('grabbed', []) or
          action not in ('blinkerLeft', 'blinkerRight') or action not in device.get('mapping', {}).values() or
          event.get('repeat') or event['time'] <= cancelled.get(mac, 0) or
          (learning.get('address') == mac and learning.get('until', 0) > now)):
        continue
      result.append({'id': event['id'], 'time': event['time'], 'direction': 'left' if action=='blinkerLeft' else 'right', 'device':mac})
    return result[-4:]


def main(fd, spas=False, ble=False):
  if spas:
    import os
    try:
      os.sched_setaffinity(0, {0, 1, 2, 3})
      os.nice(10)
    except OSError:
      pass
  from openpilot.cereal import messaging
  from openpilot.selfdrive.carrot.bluetooth.model import RUNTIME, config, read_json, atomic_json
  from openpilot.selfdrive.carrot.bluetooth.physical import HOLD_PATH
  from openpilot.common.params import Params
  from openpilot.cereal import car
  with car.CarParams.from_bytes(Params().get('CarParams')) as cp:
    fingerprint = cp.carFingerprint
    front_radar_available = not getattr(cp, 'radarUnavailable', True)
    if ble and getattr(cp, 'passive', False):
      return
    if spas:
      from opendbc.car.hyundai.values import HyundaiFlags
      if cp.brand != 'hyundai' or not cp.flags & HyundaiFlags.CANFD_SPAS_BLINKERS or cp.passive:
        return
  if not spas and not ble and json.loads(PACKAGE_CONFIG.read_text()).get('fingerprint') != fingerprint:
    return
  sock = socket.socket(fileno=fd)
  sock.setblocking(False)
  sm = messaging.SubMaster(['carState', 'carControl', 'selfdriveState', 'pandaStates', 'modelV2', 'carrotMan', 'livePose', 'radarState',
                             'gpsLocation', 'gpsLocationExternal', 'carrotNavi'])
  events = Events(time.monotonic())
  trial_until = 0.
  last_trial = None
  policy, params = Policy(), Params()
  automatic = AutomaticSignals()
  tbt = TbtBlinker()
  boundary = BoundaryEvents(read_json(RUNTIME/'boundary-indicator.json', {}))
  observation = ObservationSignals(read_json(RUNTIME/'boundary-indicator.json', {}))
  low_speed_ownership, travel = LowSpeedOwnership(), Travel()
  display = Publisher()
  feedback, activated_id = {}, None
  observation_feedback, tap_echo = ObservationFeedback(), TapEcho()
  release_until = 0.
  def record_ownership(value):
    previous = read_json(RUNTIME/'boundary-indicator.json', {})
    previous = previous if isinstance(previous, dict) else {}
    stamp = previous.get('time')
    mask = previous.get('mask', previous.get('direction', 0))
    if finite(stamp) and 0 <= time.monotonic()-stamp < 20 and type(mask) is int and mask in (1, 2, 3):
      value = {**value, 'mask':value.get('mask', value['direction']) | mask}
    atomic_json(RUNTIME/'boundary-indicator.json', value)
  while True:
    now = time.monotonic()
    for _ in range(8):
      if not select.select([sock], [], [], 0)[0]:
        break
      raw = sock.recv(LIMIT+1)
      if not raw:
        return
      try:
        value = json.loads(raw) if len(raw) <= LIMIT else None
        if isinstance(value, dict):
          feedback = value
      except ValueError:
        feedback = {}
    sm.update(0)
    now = time.monotonic()  # SubMaster assigns receive timestamps during update.
    ok = vehicle_ready(sm, now, fingerprint, spas or ble)
    status = read_json(RUNTIME/'status.json', {})
    settings, learning, cancelled = config(), read_json(RUNTIME/'learn.json', {}), read_json(RUNTIME/'cancelled.json', {})
    commands = events.read(read_json(RUNTIME/'blinker.json', {}), settings, status, learning, cancelled, now)
    remote = False
    if policy.hold and policy.hold['source'] == 'bluetooth' and fresh(status.get('time'), now):
      mac = policy.hold.get('device')
      device = settings.get('devices', {}).get(mac, {})
      action = 'blinkerLeft' if policy.hold['direction'] == 'left' else 'blinkerRight'
      remote = (mac in status.get('grabbed', []) and device.get('enabled') is True and
                action in device.get('mapping', {}).values() and policy.hold['time'] > cancelled.get(mac, 0) and
                not (learning.get('address') == mac and learning.get('until', 0) > now))
    cs = sm['carState']
    mode = params.get_int('AutoBlinkerControl')
    mode = mode if mode in (0, 1, 2) else 0
    auto_fresh = all(k in sm.services and sm.valid[k] and sm.alive[k] and
                     fresh(sm.recv_time[k], now, 1.0 if k == 'carrotMan' and automatic.direction else .35)
                     for k in ('modelV2', 'carrotMan'))
    travelled = travel.update(now, cs.vEgo, ok)
    auto_valid = auto_fresh and ok and automatic_control_allowed(
      cs, sm['carControl'], sm['selfdriveState'], params.get_bool('AlwaysLateral'), automatic.direction is not None)
    auto_valid = auto_valid and not navigation_cancelled(sm, now)
    auto = None
    if auto_fresh:
      meta, ss = sm['modelV2'].meta, sm['selfdriveState']
      position, target = turn_observations(sm, now)
      auto = automatic.update(now, mode, auto_valid,
                              ss.atcTurnStartMonoTime / 1e9, str(ss.atcTurnDirection), sm['carrotMan'].atcType,
                              str(meta.desire), str(meta.autoTurnSignal) if meta.autoTurnSignalLaneChange and sm['carControl'].latActive else None,
                              speed=cs.vEgo, angle=cs.steeringAngleDeg, heading=turn_heading(sm, now),
                              distance=sm['carrotMan'].xDistToTurn, position=position, target=target,
                              travel=travelled, use_travel=True,
                              pressed=getattr(cs, 'steeringPressed', False), torque=getattr(cs, 'steeringTorque', 0.))
    else:
      automatic.update(now, mode, False, 0., 'none', '', 'none', use_travel=True)
    # The ATC add-on lights the real right indicator. Its CAN feedback goes through the
    # unchanged driver-blinker lane-change path; no LANECHANGE command is sent.
    tbt_distance = right_lane_change_distance(params)
    tbt_enabled = (not spas and mode == 2 and params.get_int('AutoTurnControl') in (1, 2) and
                   tbt_distance > 0)
    front_clear = (tbt_enabled and front_radar_available and 'radarState' in sm.services and sm.valid['radarState'] and
                   sm.alive['radarState'] and fresh(sm.recv_time['radarState'], now, .35) and
                   right_front_clear(sm['radarState']))
    tbt_auto = tbt.update(now, enabled=tbt_enabled, distance_limit=tbt_distance,
                          front_clear=front_clear,
                          valid=(auto_valid and fresh(sm.recv_time['carrotMan'], now, .35) and
                                 sm['carControl'].latActive and params.get_int('LaneChangeNeedTorque') == 0),
                          cs=cs, model=sm['modelV2'] if auto_fresh else None, nav=sm['carrotMan'] if auto_fresh else None,
                          manual=bool(commands) or (fresh(feedback.get('stamp'), now, .35) and feedback.get('state') == 'driver_override'),
                          busy=auto is not None or (policy.hold is not None and tbt.phase not in ('waiting', 'changing', 'finishing')))
    if tbt_auto is not None:
      if tbt_auto[0] != 'tbt_display' or low_speed_ownership.ready(now, tbt.started, sm['modelV2'].meta,
          record_ownership):
        auto = tbt_auto
    model_fresh = ('modelV2' in sm.services and sm.valid['modelV2'] and sm.alive['modelV2'] and fresh(sm.recv_time['modelV2'], now, .35))
    meta = sm['modelV2'].meta if model_fresh else None
    observed_source = str(getattr(meta, 'observedIndicatorSource', ''))
    observation_enabled = (params.get_bool('ManualLaneChangeIndicator') if observed_source == 'manual' else
                           params.get_bool('ModelPathIndicator') if observed_source == 'model_path' else
                           params.get_bool('ModelDesireIndicator') if observed_source in ('model_desire', 'model_turn') else False)
    own_tap = (observation.owned is not None and tap_echo.matches(
      now, cs, observation.owned[1], observation.owned[0], observation_feedback.value))
    observe_auto = observation.update(now, meta,
      allowed=(not spas and mode in (1, 2) and observation_enabled and ok and model_fresh and
               observation_allowed(cs, sm['carControl'], sm['modelV2'], observed_source, now, observation.owned is not None, own_tap) and
               (observation.owned is not None or fresh(feedback.get('stamp'), now, .35) and feedback.get('state') == 'ready')),
      busy=bool(commands) or auto is not None or (policy.hold is not None and policy.hold['source'] != 'observation') or
           (fresh(feedback.get('stamp'), now, .35) and feedback.get('state') == 'driver_override'),
      record=record_ownership)
    if auto is None and observe_auto:
      auto = observe_auto
    local_observation = (auto is not None and auto[0] == 'observation') or (auto is None and (policy.hold is None or policy.hold['source'] == 'observation'))
    policy_valid = (ok and model_fresh) if local_observation else auto_valid
    commands, hold = policy.update(now, mode, ok, commands, cs.vEgo, cs.steeringAngleDeg,
                                  str(cs.gearShifter), remote, auto, policy_valid)
    observation_feedback.prepare(now, hold, meta, cs)
    receiver_override = fresh(feedback.get('stamp'), now, .35) and feedback.get('state') == 'driver_override'
    relay_output = ble and feedback.get('relay') is True
    native_hold = (not ble or fingerprint == 'HYUNDAI_IONIQ_5_PE') and not relay_output
    tbt_turn_hold = bool(not spas and native_hold and hold and hold['source'] == 'turn' and automatic.journey.active)
    # A confirmed TBT lamp is maintained by the comma-side lease. Receiver
    # one-touch ownership ending must not erase the ongoing turn. This cannot
    # activate a hold whose initial send and lamp were never acknowledged.
    continuing_turn = (tbt_turn_hold and activated_id == hold['id'] and fresh(feedback.get('stamp'), now, .35) and
                       feedback.get('state') in ('ready', 'waiting', 'driver_override') and
                       feedback.get('accepted_id') in (None, hold['id']))
    hold = policy.acknowledged(now, activated_id, receiver_override and not tbt_turn_hold)
    acknowledged = (hold and fresh(feedback.get('stamp'), now, .35) and feedback.get('accepted_id') == hold['id'] and
                    feedback.get('state') in ('ready', 'waiting', 'waiting_previous_signal')) or continuing_turn
    if not acknowledged:
      if activated_id is not None:
        release_until = now+.8
      activated_id = None
    elif ((hold['direction'] == 'left' and cs.leftBlinker and not cs.rightBlinker) or
          (hold['direction'] == 'right' and cs.rightBlinker and not cs.leftBlinker)):
      activated_id = hold['id']
    activated_id = observation_feedback.activation(now, hold, cs, feedback, acknowledged, activated_id, ok)
    if feedback.get('state') == 'driver_override' and not continuing_turn:
      release_until = 0.
    if commands or ((spas or not native_hold) and feedback.get('state') == 'driver_override'):
      automatic.pending = None
      automatic.journey.pending = None
      automatic.journey.active = None
      automatic.journey.cancelled_until = now+3.
    if not spas and not relay_output and policy.relight(now, activated_id, acknowledged and not receiver_override, cs.leftBlinker, cs.rightBlinker,
                                  retry_unlit=auto_valid and automatic.direction is not None and feedback.get('state') == 'ready'):
      hold, activated_id = policy.hold, None
    model_fresh = ('modelV2' in sm.services and sm.valid['modelV2'] and sm.alive['modelV2'] and fresh(sm.recv_time['modelV2'], now, .35))
    meta = sm['modelV2'].meta if model_fresh else None
    boundary_direction = {'left':1, 'right':2}.get(str(getattr(meta, 'manualLaneIndicator', 'none')), 0)
    boundary_commands = boundary.read(now, boundary_direction,
      getattr(meta, 'manualLaneIndicatorMonoTime', 0)/1e9,
      allowed=(not hasattr(meta, 'observedIndicator') and not spas and mode in (1, 2) and params.get_bool('ManualLaneChangeIndicator') and
               ok and model_fresh and not commands and not hold and
               boundary_vehicle_allowed(cs, boundary_direction) and
               adjacent_lane(cs, sm['modelV2'], boundary_direction, now) and
               str(meta.laneChangeState) in ('off', 'preLaneChange') and
               fresh(feedback.get('stamp'), now, .35) and feedback.get('state') == 'ready'),
      record=record_ownership)
    commands = commands + boundary_commands
    display.update(now, mode=mode, ok=ok, cs=cs, meta=meta, hold=hold,
      activated=hold is not None and activated_id == hold['id'],
      peer=feedback.get('state') if fresh(feedback.get('stamp'), now, .35) else 'missing',
      automatic=automatic, tbt=tbt, tbt_enabled=tbt_enabled and auto_fresh, front_clear=front_clear,
      observed_source=observed_source, auto_valid=auto_valid, atc_type=sm['carrotMan'].atcType if auto_fresh else '')
    devices = [mac for mac in status.get('grabbed', []) if fresh(status.get('time'), now) and
               settings.get('devices', {}).get(mac, {}).get('enabled') is True and
               not (learning.get('address') == mac and learning.get('until', 0) > now)]
    # Physical, local-only service test. A fresh nonce permits one tap while
    # parked. Keep checking P/standstill/control state for its whole lease.
    if ble:
      trial = read_json(RUNTIME/'b1-park-test.json', {})
      if isinstance(trial, dict) and trial.get('id') != last_trial and fresh(trial.get('time'), now):
        if isinstance(trial.get('id'), str) and trial['id'].startswith('park-test:') and trial.get('direction') in ('left','right'):
          last_trial = trial['id']
          trial_until = now + 1.
      if now < trial_until:
        cc, ss = sm['carControl'], sm['selfdriveState']
        ok = (ok and str(cs.gearShifter)=='park' and cs.standstill and abs(cs.vEgo)<.01 and
              not (cc.enabled or cc.latActive or cc.longActive or ss.enabled or ss.active))
        commands = [trial] if ok and isinstance(trial, dict) and trial.get('id')==last_trial and fresh(trial.get('time'),now) else []
        hold = None
    submitted = False
    try:
      sock.send(encode({'stamp': now, 'ok': bool(ok), 'events': commands, 'hold': wire_hold(hold), 'devices':devices,
                        'activated':activated_id is not None, 'relights':policy.relights,
                        'b1_hold':ble and (relay_output or fingerprint != 'HYUNDAI_IONIQ_5_PE'),
                        'turn_phase':automatic.reason, 'turn_position':bool(automatic.journey.active and automatic.journey.active['target'] is not None),
                        'tbt_phase':tbt.reason, 'observation_phase':observed_source,
                        'indicator_origin':hold['source'] if hold else None}))
      submitted = True
    except BlockingIOError:
      pass  # Never buffer commands for delivery after congestion.
    if mode and not spas:
      atomic_json(HOLD_PATH, {'stamp':now, 'mode':mode, 'fingerprint':fingerprint,
                             'direction':hold['direction'] if hold and activated_id == hold['id'] else None,
                             'tap':observation_feedback.sent(now, feedback, submitted and ok),
                             'override':activated_id is not None or now < release_until or (policy.suppressed and release_until > 0)})
    time.sleep(max(0, now+.05-time.monotonic()))


if __name__ == '__main__':
  main(int(sys.argv[1]), 'spas' in sys.argv[2:], 'ble' in sys.argv[2:])
