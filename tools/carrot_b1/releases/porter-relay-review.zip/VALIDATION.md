# Validation — 2026-11-14

This is a bench software result. Physical GPIO levels, relay polarity, switch contacts,
radio timing and vehicle behavior were not measured. Hardware wiring is NOT final.
No vehicle CAN transmission, live command, installation, restart or remote push occurred.

- Actual Arduino-ESP32 3.3.5 ESP32-S3 N16R8-target compile: PASS.
  App uses 644171 / 3145728 bytes; globals 33828 / 327680 bytes.
- ESP32-S3 image header/app descriptor/appended SHA-256/relay release marker: PASS.
- Linked app has no twai_transmit, twai_driver_install, twai_start or twai_receive symbols.
- Production controller boundary cases, uint32/uint16 rollover and 500000 randomized steps: PASS.
  Built using -Wall -Wextra -Werror -fsanitize=address,undefined.
- Actual .ino compiled/executed against desktop BLE/NVS/GPIO/OTA doubles: PASS.
  Includes invalid HMAC, stale/future/session/replay rejection, existing key retention,
  STOP, output exclusion, independent timer cutoff, disconnect, shutdown, max time,
  OTA output suppression and unclaimed-board OFF.
  Hardware APIs are doubled; this does not prove physical behavior or RF latency.
- BLE/relay/OTA/registration/badge regressions: 31 PASS.
  Includes v2/v3 enrollment, real Monitor feeding production C++ controller for both
  directions, immediate hold cancellation, no fake lamp feedback, no auto cross-flash,
  and actual blink_source loop recognition of the relay variant.
- Existing indicator policy/source/TBT/recovery/feedback regression suite: 497 PASS.
- git diff --check and complete patch git apply --cached --check against base index: PASS.

Python suites were run in separate fresh processes because their short-name `server`
imports collide when combined. Initial setup also needed jeepney, pycapnp and
setproctitle; the final runs passed. Three pytest config warnings per suite concern
unloaded optional asyncio/C++ plugins; no tests were skipped on that basis.
No full openpilot/AGNOS native build or physical Bluetooth/vehicle test was performed.

Reproduce Python checks from repository root (pytest, jeepney, pycapnp, setproctitle,
NumPy and repository Python dependencies installed):

```sh
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH="$PWD/tools/jetlink:$PWD" python -m pytest \
  --noconftest -o addopts='' -q \
  tools/jetlink/test_blinker.py tools/jetlink/test_blinker_auto.py \
  tools/jetlink/test_blinker_tbt.py tools/jetlink/test_blinker_recovery.py \
  tools/jetlink/test_indicator_feedback.py

PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH="$PWD/tools/jetlink:$PWD" python -m pytest \
  --noconftest -o addopts='' -q \
  openpilot/selfdrive/carrot/bluetooth/tests/test_b1.py \
  tools/carrot_b1/test_relay_host.py tools/carrot_b1/test_auto_update.py \
  tools/carrot_b1/test_ble_update.py
```

The included app image is a separate BENCH-ONLY artifact with provisional GPIO4/5,
active-HIGH assumptions. It is deliberately absent from the existing CAN automatic
update image path. Confirm the actual ESP32-S3 board, relay module/polarity and
Porter switch-terminal circuit before finalizing a hardware-targeted image/wiring.
See README.md for the provisional schematic and required external reset pull-downs.

Later bench observations and corrected jumper guidance: see README.md. No firmware image change.
